
=== March ===

Contributors: 
Author: Trevor Young
Version: 1.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, two-columns, right-sidebar, left-sidebar, flexible-header, custom-colors, custom-menu, editor-style, featured-images, post-formats, sticky-post, theme-options, threaded-comments

== Description ==

March (March Madness) is part of the monthly theme development that I'm working on. It's best suited for blogs

* Responsive Layout
* Right Sidebar
* Featured Images
* 

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in Golden Black in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
5. Navigate to Appearance > Customize in your admin panel and customize.

== Copyright ==

Social Media Plugin: Lightweight Social Plugin
Posts from: gbaksspeakson.blogspot.com
License: Creative Commons CC0.
Source: 
