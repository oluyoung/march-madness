    <?php
    the_posts_pagination( array(
        'mid_size' => 2,
        'prev_text' => __( '<span class="multi-posts-nav">Previous</span>', 'march' ),
        'next_text' => __( '<span class="multi-posts-nav">Next</span>', 'march' ),
    ) );
    ?>
