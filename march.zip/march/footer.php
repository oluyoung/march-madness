<footer></footer>
</section>
<?php wp_footer(); ?>
</body>
</html>
